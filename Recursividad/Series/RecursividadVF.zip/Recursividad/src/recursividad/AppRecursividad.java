
package recursividad;
import java.util.Scanner;


public class AppRecursividad 
{
   static Scanner sc = new Scanner(System.in);
   
    public static void main(String[] args) 
    {
      double x = 3.14159/3;
      System.out.println("ingrese el numero de terminos que desea calcular: ");
      int n = sc.nextInt(); 
       }
    
    public static void menu(int n, double x)
    {
       Series s = new Series();
       System.out.println("seleccione la serie que desea calcular:  "); 
       System.out.println("1. Euler    2.  Coseno    3. Seno");
       int op  = sc.nextInt();
       switch(op)
       {
           case 1:
               System.out.println("el valor de euler: "+ s.sumatoriaEuler(x, n, 0));
               break;
           case 2: 
               System.out.println("el valor de euler: "+ s.sumatoriaCoseno(x, n, 0));
               break;
           case 3:
               System.out.println("el valor de euler: "+ s.sumatoriaSeno(x, n, 0));
               break;
           default:
               System.out.println("Opcion no reconocida para este ejercicio");
               
       }
       
    }
    
}
