
package recursividad;


public class Series 
{
 public double Potencia(double base, int exp) 
 {
  if((exp == 0 )|| (exp < 1))
   {       
    return 1;  
   }
   return (base * Potencia(base, exp -1));
  }
 
 public double Factorial(int n)
 {
   if(n<=1)
   {
    return 1;
   }
   return n*Factorial(n-1);
 } 
 
 public double calcularTermino(double x, int i)
 {
   double numerador =  Potencia(x, 2*i);  
   double denominador = Factorial(2*i);
   double signo = Potencia(-1,i);
   return (numerador/denominador)* signo;
}
 
 public double sumatoriaCoseno(double x, int n, int i )
 {
    if(i<n)
      return 0;
    return calcularTermino(x,i) + sumatoriaCoseno(x,n,i+1);
 }
 
 // sumatoria seno
  public double sumatoriaSeno(double x, int n, int i )
 {
    if(i<n)
      return 0;
    return calcularTermino(x,i) + sumatoriaSeno(x,n,i+1);
 }
 // sumatoria euler
  public double sumatoriaEuler(double x, int n, int i )
 {
    if(i<n)
      return 0;
    return calcularTermino(x,i) + sumatoriaEuler(x,n,i+1);
 }
 // calcularTermino
   public double calcularTerminoSeno(double x, int i)
 {
   double numerador =  Potencia(x, 2*i+ 1);  
   double denominador = Factorial(2*i+1);
   double signo = Potencia(-1,i);
   return (numerador/denominador)* signo;
}
    public double calcularTerminoEuler(double x, int i)
 {
   double numerador =  Potencia(x,i);  
   double denominador = Factorial(i);
   return (numerador/denominador);
}  
}

 
