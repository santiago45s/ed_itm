
package recursividad;


public class Series 
{
 public double Potencia(double base, int exp) 
 {
  if((exp == 0 )|| (exp < 1))
   {       
    return 1;  
   }
   return (base * Potencia(base, exp -1));
  }
 
 public double Factorial(int n)
 {
   if(n<=1)
   {
    return 1;
   }
   return n*Factorial(n-1);
 } 
 
 public double calcularTermino(double x, int i)
 {
   double numerador =  Potencia(x, 2*i);  
   double denominador = Factorial(2*i);
   double signo = Potencia(-1,i);
   return (numerador/denominador)* signo;
}
 
 public double sumatoriaCoseno(double x, int n, int i )
 {
    if(i<n)
      return 0;
    return calcularTermino(x,i) + sumatoriaCoseno(x,n,i+1);
 }
}

 
