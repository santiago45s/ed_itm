package pr_estudiante;

import java.util.Scanner;

public class Estudiante 
{
  private String nombre;
  private int edad;
  private String genero;
  private double notaDef;

    public Estudiante(String nombre, int edad, String genero, double notaDef) 
    {
        this.nombre = nombre;
        this.edad = edad;
        this.genero = genero;
        this.notaDef= notaDef; 
    }

    public Estudiante() 
    {
        
    }
    
    public Estudiante leerDatos()
    {
      Scanner sc = new Scanner(System.in);
      System.out.println("ingrese nombre de estudiante: ");
      nombre = sc.nextLine();
      System.out.println("ingrese genero de estudiante: ");
      genero = sc.nextLine();
      System.out.println("ingrese edad de estudiante: ");
      edad= sc.nextInt();
      System.out.println("ingrese nota definitiva de estudiante: ");
      notaDef= sc.nextDouble();
      return new Estudiante(nombre, edad, genero, notaDef);    
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    @Override
    public String toString() 
    {
        return "Estudiante{" + "nombre=" + nombre + ", edad=" + edad + ", genero=" + genero + ",notaDef= " + notaDef + "}";
    }
    
    

    


  
}
